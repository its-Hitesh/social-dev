// export const BASE_URL = "http://164.92.79.219/v1";
// export const BASE_URL = "http://localhost:8000/api/v1";
export const BASE_URL = "http://167.71.61.146/api/v1";

// export const BASE_URL = "https://gitvisual-production.up.railway.app/v1";

export const BASE_URL_IMG = "https://gitvisual-production.up.railway.app/";
// export const BASE_URL_IMG = "http://localhost:3000/";
// export const BASE_URL_IMG = "http://164.92.79.219";
// export const BASE_URL_IMG_Local = "http://localhost:3000";
// export const BASE_URL_IMG_Local = "http://localhost:3000";
// export const BASE_URL_Local = "http://localhost:3000/v1";
// export const BASE_URL_SOCKET = "https://gitvisual-production.up.railway.app/";
export const BASE_URL_SOCKET = "http://167.71.61.146";
// export const BASE_URL_SOCKET = "https://git-visual-backend-public-production.up.railway.app/";
// export const BASE_URL_SOCKET = "http://localhost:3000";
